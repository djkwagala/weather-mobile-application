
angular.module('controllers',[])
.controller('loginCtrl', function($scope, $ionicPlatform) {

	$scope.opennav2 = function(){
	
	document.getElementById("setme").innerHTML="hi guys please work";
	}


});
