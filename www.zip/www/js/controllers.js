angular.module('wimeaApp.controllers',['ionic.contrib.drawer'])
.controller('loginCtrl', function($scope, $ionicModal) {

	$scope.opennav2 = function(){
	
	document.getElementById("setme").innerHTML="hi guys please work";
	}


});
