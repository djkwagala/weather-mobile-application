var db = null;
var observDataFetched = [];
var metarDataFetched = [];
var moreDataFetched = [];

var stationnamefetched = "";
var stationnumberfetched = "";
var OriginalUserName ="";
var firstLogin =false;

angular.module('wimeaApp',['ionic','ionic.contrib.drawer', 'ngCordova'])
.run(function($ionicPlatform, $cordovaSQLite) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  //db = window.sqlitePlugin.openDatabase({ name: 'app.db' });
  // db = $cordovaSQLite.openDB("my.db");


   db = window.openDatabase("my.db", '1', 'my', 1024 * 1024 * 100);

  //db = openDatabase('mydb', '1.0', 'Test DB', 2 * 1024 * 1024);
  // db = window.sqlitePlugin.openDatabase("my.db");
  $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS usersDetailsTable(username, password, stationName,stationNumber)");
   $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS metarData (Date,StationName, StationNumber, TIME, METARSPECI, CCCC, YYGGgg, Dddfffmfm, WWorCOVAK, W1W1, NlCCNmCCNhCC, Air_temperature, Dew_temperature, Wet_bulb, TTTdTd, Qnhhpa, Qnhin, Qfehpa, Qfein, REW1W1, CreationDate, SubmittedBy)");
   $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS moreFormTable (Date, StationName, StationNumber, TIME, UnitOfWindSpeed, IndOrOmissionOfPrecipitation, TypeOfStation_Present_Past_Weather, HeightOfLowestCloud, StandardIsobaricSurface, GPM, DurationOfPeriodOfPrecipitation, Past_Weather, GrassMinTemp, CI_OfPrecipitation, BE_OfPrecipitation, IndicatorOfTypeOfIntrumentation, DurationOfSunshine, SignOfPressureChange, Supp_Info, VapourPressure, Wind_Run, T_H_Graph,SubmittedBy, CreationDate)");
   $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS observationTable(Date,  StationName,  StationNumber,  TIME,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds, OktasOfLowClouds, HeightOfLowClouds, CLCODEOfLowClouds, TypeOfMediumClouds, OktasOfMediumClouds, HeightOfMediumClouds, CLCODEOfMediumClouds,TypeOfHighClouds, OktasOfHighClouds, HeightOfHighClouds, CLCODEOfHighClouds, CloudSearchLightReading, Rainfall,Dry_Bulb, Wet_Bulb, Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec , Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,CLP,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,SubmittedBy,CreationDate)");

   var queryuser = "SELECT * FROM usersDetailsTable";
   $cordovaSQLite.execute(db, queryuser).then(function(res) {
       if(res.rows.length > 0) {
         OriginalUserName = res.rows.item(0).username;
         stationnamefetched = res.rows.item(0).stationName;
          stationnumberfetched = res.rows.item(0).stationNumber;
       }else{

firstLogin=true;

       }
     })


   var query = "SELECT * FROM observationTable";
   $cordovaSQLite.execute(db, query).then(function(res) {
     var i=0;
       if(res.rows.length > 0) {
          // alert("SELECTED -> " + res.rows.item(0).StationName + " " + res.rows.item(0).StationNumber);
            while(i<res.rows.length){
           observDataFetched.push(res.rows.item(i).TIME);

           i++;
         }
          //  alert(observDataFetched.length);
       } else {
           console.log("No results found");
       }
   }, function (err) {
       console.error(err);
   });

   var queryMeta = "SELECT * FROM metarData";
   $cordovaSQLite.execute(db, queryMeta).then(function(res) {
     var i=0;
       if(res.rows.length > 0) {
          // alert("SELECTED -> " + res.rows.item(0).StationName + " " + res.rows.item(0).StationNumber);
            while(i<res.rows.length){
           metarDataFetched.push(res.rows.item(i).TIME);
           i++;
         }
         //alert(metarDataFetched.length);

       } else {
           console.log("No results found");
       }
   }, function (err) {
       console.error(err);
   });

   var queryMore = "SELECT * FROM moreFormTable";
   $cordovaSQLite.execute(db, queryMore).then(function(res) {
     var i=0;
       if(res.rows.length > 0) {
          // alert("SELECTED -> " + res.rows.item(0).StationName + " " + res.rows.item(0).StationNumber);
          while(i<res.rows.length){
           moreDataFetched.push(res.rows.item(i).TIME);

           i++;
         }
         //alert(moreDataFetched.length)
       } else {
           console.log("No results found");
       }
   }, function (err) {
       console.error(err);
   });
  });
})

.config(function($stateProvider,$urlRouterProvider){

	//routing through the applications
	$stateProvider
	.state('main',{
		url : '/main',
		 abstract: true,
    	templateUrl: 'templates/main.html',
		controller:'menuCtrl'

	})
	.state('login',{
		url : '/login',

		templateUrl: 'templates/login.html',
		controller:'loginCtrl'
	})
	.state('main.observationform',{
		url : '/observationform',
		views: {
		'menuContent': {
     	templateUrl: 'templates/observationform.html',
		controller:'observationformCtrl'
		}
		}
	})
  .state('main.pendingUpload',{
		url : '/pendingUpload',
		views: {
		'menuContent': {
     	templateUrl: 'templates/pendingUploads.html',
		controller:'pendingUploadCtrl'
		}
		}
	})
	.state('observationform2',{
		url : '/observationform2',
		templateUrl: 'templates/observationform2.html',
		controller:'observationform2Ctrl'

	})

	.state('main.moreformfieldsform',{
		url : '/moreformfieldsform',
		views: {
		'menuContent': {
     	templateUrl: 'templates/moreformfieldsform.html',
		controller:'moreformfieldsformCtrl'
		}
		}
	})

	$urlRouterProvider.otherwise('/login');

})

.factory('mobileDb', function (){

  function initDB() {

  			  db = $cordovaSQLite.openDB("myapp.db");

  			   var query = "CREATE TABLE IF NOT EXISTS trackers_list (id in-teger autoincrement primary key, name string)";
  			    runQuery(query,[],function(res) {
  			      console.log("table created ");
  			    }, function (err) {
  			      console.log(err);
  			    });

  		}

      return {
        createDb:function() {
          initDB();
        }

      }

})
.factory('GeoAlert', function() {
   console.log('GeoAlert service instantiated');
   var interval;
   var duration = 6000;
   var long, lat;
   var processing = false;
   var callback_positive;
    var callback_negative;
    var callback_error;
   var minDistance = 1;

   // Credit: http://stackoverflow.com/a/27943/52160
   function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
    var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(lat2-lat1);  // deg2rad below
    var dLon = deg2rad(lon2-lon1);
    var a =
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
      Math.sin(dLon/2) * Math.sin(dLon/2)
      ;
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    var d = R * c; // Distance in km
    return d;
   }

   function deg2rad(deg) {
    return deg * (Math.PI/180)
   }

   function hb() {

       console.log('hb running');
       if(processing) return;
       processing = true;

       AdvancedGeolocation.start(function(success){

           try{
               var jsonObject = JSON.parse(success);

               switch(jsonObject.provider){
                   case "gps":
                   if(jsonObject.latitude != "0.0" || jsonObject.longitude != "0.0"){
                     processing = false;
                     console.log(jsonObject.latitude, jsonObject.longitude);
                     var dist = getDistanceFromLatLonInKm(lat, long, jsonObject.latitude, jsonObject.longitude);
                     console.log("dist in km is "+dist);
                     if(dist <= minDistance) callback_positive();
                     else callback_negative();
                   }else
                     alert("Detection Failed");

                       break;

                   case "network":
                   if(jsonObject.latitude != "0.0" || jsonObject.longitude != "0.0"){
                    // alert("detected");
                     processing = false;
                     console.log(jsonObject.latitude, jsonObject.longitude);
                     var dist = getDistanceFromLatLonInKm(lat, long, jsonObject.latitude, jsonObject.longitude);
                     console.log("dist in km is "+dist);
                     if(dist <= minDistance) callback_positive();
                     else callback_negative();
                   }else
                     alert("Detection Failed");

                       break;

                   case "satellite":
                        //TODO
                       break;

                   case "cell_info":
                    //TODO
                    break;

                   case "cell_location":
                    //TODO
                    break;

                   case "signal_strength":
                    //TODO
                    break;
               }
           }
           catch(exc){
               console.log("Invalid JSON: " + exc);
                alert("Invalid JSON: " + exc );
           }
       },
       function(error){
           console.log("ERROR! " + JSON.stringify(error));
           alert("Try again when GPS Location is on! " );
           callback_error();

       },
       {
           "minTime":30*60000,         // Min time interval between updates (ms)
           "minDistance":1,       // Min distance between updates (meters)
           "noWarn":true,         // Native location provider warnings
           "providers":"all",     // Return GPS, NETWORK and CELL locations
           "useCache":true,       // Return GPS and NETWORK cached locations
           "satelliteData":false, // Return of GPS satellite info
           "buffer":false,        // Buffer location data
           "bufferSize":0,         // Max elements in buffer
           "signalStrength":false // Return cell signal strength data
       });


    }


   return {
     begin:function(lt,lg,cb_pos,cb_neg,cb_err) {
       long = lg;
       lat = lt;
       callback_positive = cb_pos;
       callback_negative=cb_neg;
       callback_error=cb_err;
       hb();
     },
     comfirmLocation: function(){
      cordova.plugins.diagnostic.isGpsLocationEnabled(function(available){
      console.log("Location is " + (available ? "available" : "not available"));

      if(!available){
        alert("Turn on Location");

        cordova.plugins.diagnostic.switchToLocationSettings();
       }

  }, function(error){
      console.error("The following error occurred: "+error);

  });
},end: function(){
  AdvancedGeolocation.kill(function(){
    //alert("stopped");
  },function(){
      alert("stop error");
  });
    },
     setTarget: function(lg,lt) {
       long = lg;
       lat = lt;
     }
   };

})
.service('LoginService', function ($q, $http) {
      var user=""; var userStationNo=""; var userStation="";
  return {
    loginUser: function (loginData) {
        var deferred = $q.defer(),
        promise = deferred.promise;


        $http({
          url: 'http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/loginMobile.php',
          method: "POST",
          data: loginData,
          headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })    .then(function (response) {
          if (response.data.error.code === "000") {
            //console.log("User login successful: " + JSON.stringify(response.data));
            deferred.resolve("Welcome");
            user = response.data.userData.name;
            userStationNo=response.data.userData.stationNumber;;
             userStation=response.data.userData.stationName;;

          } else {
            //console.log("User login failed: " + JSON.stringify(response.data.error));
            deferred.reject("Wrong credential");
          }
        }, function (error) {
          //console.log("Server Error on login: " + JSON.stringify(error));
          deferred.reject("Wrong credential");
        });

        promise.success = function (fn) {
          promise.then(fn);
          return promise;
        };
        promise.error = function (fn) {
          promise.then(null, fn);
          return promise;
        };
        return promise;
      }, getUser: function(){
            return user;
      }, getUserStation: function(){
            return userStation;
      }
      , getUserStationNo: function(){
            return userStationNo;
      }
}
})


.controller('loginCtrl', function($scope,  LoginService, $http, $ionicPopup,$state, $ionicModal, $cordovaSQLite) {

	$scope.opennav2 = function(){
	$state.go('main.observationform');
	}
  $scope.insertUserInDb = function(username, password, stationName,stationNumber){

        var query = "INSERT INTO usersDetailsTable (username, password, stationName, stationNumber) VALUES (?,?,?,?)";
        $cordovaSQLite.execute(db, query, [username, password, stationName,stationNumber]).then(function(res) {
            console.log("INSERT ID -> " + res.insertId);

        }, function (err) {
            console.error(err);
            //alert(JSON.stringify(err));
        });




    }

  $scope.data={};
  $scope.login = function() {


    $scope.loginData = {
      'userName' : $scope.data.username,
      'password' : $scope.data.password
    };



    if($scope.loginData.userName !=null && $scope.loginData.password !=null) {

      var query = "SELECT * FROM usersDetailsTable";
      $cordovaSQLite.execute(db, query).then(function(res) {
          if(res.rows.length > 0) {
            if($scope.data.username==res.rows.item(0).username && $scope.data.password==res.rows.item(0).password){
                $state.go('main.observationform');
            }else{
              var alertPopup = $ionicPopup.alert({
                title: 'Wrong credentials!',
                template: 'Please check your credentials!'
              });
            }
          }
          else{
            LoginService.loginUser($scope.loginData).success(function(data) {
                $scope.insertUserInDb($scope.loginData.userName,$scope.loginData.password,LoginService.getUserStation(), LoginService.getUserStationNo());
                var queryuser = "SELECT * FROM usersDetailsTable";
                $cordovaSQLite.execute(db, queryuser).then(function(res) {
                    if(res.rows.length > 0) {
                      OriginalUserName = res.rows.item(0).username;
                      stationnamefetched = res.rows.item(0).stationName;
                      stationnumberfetched = res.rows.item(0).stationNumber;

                      //alert(stationnamefetched);

                    }else{
                      // alert("none");

                    }
                  })

            $state.go('main.observationform');


            }).error(function(data) {

              var alertPopup = $ionicPopup.alert({
                title: 'Login failed!',
                template: 'Please check your credentials!'
              });
            });
          }
        })



}
else {
//alert();
//alert("Password or email is missing");
var alertPopup = $ionicPopup.alert({
title: 'Missing fields!',
template: 'Password or email is missing!'
});
}

}





})



.controller('pendingUploadCtrl', function($scope, GeoAlert,$state,$cordovaSQLite,$ionicPopup, $ionicModal, $http, mobileDb, LoginService){
//var observDataFetched =[];
  $scope.arrayOBV =[];
  $scope.arrayMore =[];
  $scope.arrayMeta =[];
    $scope.metaFormData ={};
  $scope.arrayOBV = observDataFetched;
  $scope.arrayMeta = metarDataFetched;
  $scope.arrayMore = moreDataFetched;


$scope.selectMetarData = function(Time) {
        var query = "SELECT * FROM metarData WHERE Time = ?";
        $cordovaSQLite.execute(db, query, [Time]).then(function(res) {
            if(res.rows.length > 0) {
              $scope.metaFormData={
              "qfehpa": res.rows.item(0).Qfehpa,
              "rew1w1": res.rows.item(0).REW1W1,
              "qfein": res.rows.item(0).Qfein,
              "qnhin": res.rows.item(0). Qnhin,
              "qnhhpa": res.rows.item(0).Qnhhpa,
              "TTTd": res.rows.item(0).TTTdTd,
              "N1ch":res.rows.item(0).NlCCNmCCNhCC,
               "airTemp": res.rows.item(0).Wet_bulb,
               "dewTemp": res.rows.item(0).Dew_temperature,
              "wetBulb": res.rows.item(0).Air_temperature,
              "w1w1": res.rows.item(0).W1W1,
              "wwwcavok": res.rows.item(0).WWorCOVAK,
              "dddff": res.rows.item(0).Dddfffmfm,
              "yygggg": res.rows.item(0).YYGGgg,
              "cccc": res.rows.item(0).CCCC,
              "speci": res.rows.item(0). METARSPECI,
              "timesubmitted": res.rows.item(0). TIME,
              "snumber": res.rows.item(0).StationNumber,
              "sname": res.rows.item(0).StationName,
              "datesubmitted": res.rows.item(0).Date
              }
              if(window.Connection) {
                          if(navigator.connection.type == Connection.NONE) {
                              $ionicPopup.confirm({
                                  title: "Internet not available",
                                  content: "The data cant be submitted."
                              })
                              .then(function(result) {
                                  if(!result) {
                                    //  ionic.Platform.exitApp();
                                  }
                              });
                          }
                          else{
                            var confirmPopup = $ionicPopup.confirm({
                               title: 'confirm subimssion',
                               template: 'The data will be submitted'
                            });

                            confirmPopup.then(function(res) {
                               if(res) {
                                $scope.sendMetarDataToDb($scope.metaFormData, Time);
                              //  $scope.deleteRowFromDb(Time);
                               } else {
                                  console.log('Not sure!');
                               }
                            });
                          }
                      }
                      else{
                        var confirmPopup = $ionicPopup.confirm({
                           title: 'confirm subimssion',
                           template: 'Are you sure? Changes cant be made after this'
                        });

                        confirmPopup.then(function(res) {
                           if(res) {
                              $scope.sendMetarDataToDb($scope.metaFormData, Time);

                           } else {
                              console.log('Not sure!');
                           }
                        });
                      }

                //console.log("SELECTED -> " + res.rows.item(0).firstname + " " + res.rows.item(0).lastname);
            } else {
                console.log("No results found");
            }
        }, function (err) {
            console.error(err);
        });
    }


    $scope.deleteRowFromDb= function(Time){
      var query = "DELETE FROM metarData where Time = ?";
      $cordovaSQLite.execute(db, query, [Time]).then(function(res) {
      //$cordovaSQLite.execute(db, query).then(function(res) {
          if(res.rows.length > 0) {
              alert("successfully Delted");
          } else {
            metarDataFetched.pop(Time);
              console.log("No results found");
          }
      }, function (err) {
          console.error(err);
      });
    }



  $scope.sendMetarDataToDb = function(data_to_send, Time) {

    $http({
  method : "POST",
  url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/metaform.php",
  data: data_to_send,
  headers: {'Content-Type': 'application/x-www-form-urlencoded'}
  }).then(function mySuccess(response) {
      $scope.deleteRowFromDb(Time);
    var alertPopup = $ionicPopup.alert({
      title: 'Successful',
      template: 'Your data has been submitted!'
    });

  }, function myError(response) {
    var alertPopup = $ionicPopup.alert({
      title: 'Failed',
      template: 'Please check your network'
    });
});
          }

  $scope.sendDataOnline = function(field){
      $scope.selectMetarData(field);



  }

//submitting data for moreform

$scope.selectMoreData = function(Time) {
        var query = "SELECT * FROM moreFormTable WHERE Time = ?";
        $cordovaSQLite.execute(db, query, [Time]).then(function(res) {
            if(res.rows.length > 0) {
$scope.moreformData={
    "thgraph": res.rows.item(0).T_H_Graph,
     "windrun": res.rows.item(0).Wind_Run,
     "vapourpressure": res.rows.item(0).VapourPressure,
     "suppinfo": res.rows.item(0).Supp_Info,
     "pressuresign": res.rows.item(0).SignOfPressureChange,
     "sunshineduration": res.rows.item(0).DurationOfSunshine,
     "indicator": res.rows.item(0).IndicatorOfTypeOfIntrumentation,
     "beginpreciptation": res.rows.item(0).BE_OfPrecipitation,
      "characterintensity": res.rows.item(0).CI_OfPrecipitation,
    //  "stationtypepresent": res.rows.item(0).GrassMinTemp,
      "grassmintemp": res.rows.item(0).GrassMinTemp,
      "pastweather": res.rows.item(0).Past_Weather,
      "preciptationperiod": res.rows.item(0).DurationOfPeriodOfPrecipitation,
      "geopotential":res.rows.item(0).GPM,
      "stdiosbaricsurface": res.rows.item(0).StandardIsobaricSurface,
      "lowcloudheight": res.rows.item(0).HeightOfLowestCloud,
      "stationtype": res.rows.item(0).TypeOfStation_Present_Past_Weather,
      "IndOrOmissionOfPrecipitation": res.rows.item(0).IndOrOmissionOfPrecipitation,
      "windspeed": res.rows.item(0).UnitOfWindSpeed,
      "stime": res.rows.item(0).TIME,
      "number": res.rows.item(0).StationNumber,
      "name": res.rows.item(0).StationName,
      "sdate": res.rows.item(0).Date

    }

              if(window.Connection) {
                          if(navigator.connection.type == Connection.NONE) {
                              $ionicPopup.confirm({
                                  title: "Internet not available",
                                  content: "The data cant be submitted."
                              })
                              .then(function(result) {
                                  if(!result) {
                                    //  ionic.Platform.exitApp();
                                  }
                              });
                          }
                          else{
                            var confirmPopup = $ionicPopup.confirm({
                               title: 'confirm subimssion',
                               template: 'The data will be submitted'
                            });

                            confirmPopup.then(function(res) {
                               if(res) {
                                $scope.sendMoreDataToDb($scope.moreformData, Time);
                              //  $scope.deleteRowFromDb(Time);
                               } else {
                                  console.log('Not sure!');
                               }
                            });
                          }
                      }
                      else{
                        var confirmPopup = $ionicPopup.confirm({
                           title: 'confirm subimssion',
                           template: 'Are you sure? Changes cant be made after this'
                        });

                        confirmPopup.then(function(res) {
                           if(res) {
                             $scope.sendMoreDataToDb($scope.moreformData, Time);

                           } else {
                              console.log('Not sure!');
                           }
                        });
                      }

                //console.log("SELECTED -> " + res.rows.item(0).firstname + " " + res.rows.item(0).lastname);
            } else {
                console.log("No results found");
            }
        }, function (err) {
            console.error(err);
        });
    }


    $scope.deleteRowFromMoreDb= function(Time){
      var query = "DELETE FROM moreFormTable where Time = ?";
      $cordovaSQLite.execute(db, query, [Time]).then(function(res) {
      //$cordovaSQLite.execute(db, query).then(function(res) {
          if(res.rows.length > 0) {
              alert("successfully Delted");
          } else {
            moreDataFetched.pop(Time);
              console.log("No results found");
          }
      }, function (err) {
          console.error(err);
      });
    }


//    $scope.sendMoreDataToDb($scope.moreformData, Time);

  $scope.sendMoreDataToDb = function(data_to_send, Time) {

    $http({
  method : "POST",
  url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/moreform.php",
  data: data_to_send,
  headers: {'Content-Type': 'application/x-www-form-urlencoded'}
  }).then(function mySuccess(response) {
      $scope.deleteRowFromMoreDb(Time);
    var alertPopup = $ionicPopup.alert({
      title: 'Successful',
      template: 'Your data has been submitted!'
    });

  }, function myError(response) {
    var alertPopup = $ionicPopup.alert({
      title: 'Failed',
      template: 'Please check your network'
    });
});
          }

  $scope.sendMoreDataOnline = function(field){
      $scope.selectMoreData(field);



  }


//this submits observation data



//submitting data for moreform

$scope.selectObservData = function(Time) {
        var query = "SELECT * FROM observationTable WHERE Time = ?";
        $cordovaSQLite.execute(db, query, [Time]).then(function(res) {
            if(res.rows.length > 0) {
$scope.obsevationDataToSend={
  "dateSelected"    :res.rows.item(0).Date,
  "StationName"    :res.rows.item(0).StationName,
  "StationNumber"    :res.rows.item(0).StationNumber,
 "time"    :res.rows.item(0).TIME,
  "rainfall" : res.rows.item(0).Rainfall,
  "amountClounds"    :res.rows.item(0).TotalAmountOfAllClouds,
  "totalLowClounds"  	:res.rows.item(0).TotalAmountOfLowClouds,
  "typeLowCloud" :res.rows.item(0).TypeOfLowClouds,
  "oktasLowClouds"    :res.rows.item(0).OktasOfLowClouds,
  "lowCloudHeight"    : res.rows.item(0).HeightOfLowClouds,
  "CLCode"    :	res.rows.item(0).CLCODEOfLowClouds,
  "mediumCloudType"    :res.rows.item(0).TypeOfMediumClouds,
  "OltasMediumCloud"    :res.rows.item(0).OktasOfMediumClouds,
  "mediumCloudHeight"    :res.rows.item(0).HeightOfMediumClouds,
   "CLCODEOfMediumClouds"    :res.rows.item(0).CLCODEOfMediumClouds,
    "CLCODEOfHighClouds"    :res.rows.item(0).CLCODEOfHighClouds,
    "maxReset"    :res.rows.item(0).Max_Reset,
  "MinRead"    :	res.rows.item(0).Min_Read,
  "minReset"    :res.rows.item(0).Min_Reset,
  "picheRead"    :res.rows.item(0).Piche_Read,
  "picheReset"    :res.rows.item(0).Piche_Reset,
  "timeMarksThermo"   :res.rows.item(0).TimeMarksThermo,
  "timeMarksHygro":res.rows.item(0).TimeMarksHygro,
   "timeMarksRainRec":res.rows.item(0).TimeMarksRainRec,
  "presetWeather":res.rows.item(0).Present_Weather,
  "visibility":res.rows.item(0).Visibility,
  "windDirection":res.rows.item(0).Wind_Direction,
  "windSpeed":res.rows.item(0).Wind_Speed,
  "gusting":res.rows.item(0).Gusting,
  "clodeMediumCloud": res.rows.item(0).Gusting,
  "typeHighCloud":res.rows.item(0).TypeOfHighClouds,
  "oktasHighCloud": res.rows.item(0).OktasOfHighClouds,
   "heightHighCloud":res.rows.item(0).HeightOfHighClouds,
  "cloudsechlghtAlidade":res.rows.item(0).CloudSearchLightReading,
   "dryBulb":res.rows.item(0).Dry_Bulb,
    "wetBulb":res.rows.item(0).Wet_Bulb,
    "maxRead": res.rows.item(0).Max_Read,
    "attdThermoReading": res.rows.item(0).AttdThermo,
  "prAsReadReading": res.rows.item(0).PrAsRead,
   "correction": res.rows.item(0).Correction,
   "cldMbReading": res.rows.item(0).CLP,
    "MSLPr": res.rows.item(0).MSLPr,
    "barographTimeMarks":res.rows.item(0).TimeMarksBarograph,
    "anemographTimeMarks": res.rows.item(0).TimeMarksAnemograph,
    "otherTMarks": res.rows.item(0).OtherTMarks,
     "RemarksotherObservation": res.rows.item(0).Remarks

    }

              if(window.Connection) {
                          if(navigator.connection.type == Connection.NONE) {
                              $ionicPopup.confirm({
                                  title: "Internet not available",
                                  content: "The data cant be submitted."
                              })
                              .then(function(result) {
                                  if(!result) {
                                    //  ionic.Platform.exitApp();
                                  }
                              });
                          }
                          else{
                            var confirmPopup = $ionicPopup.confirm({
                               title: 'confirm subimssion',
                               template: 'The data will be submitted'
                            });

                            confirmPopup.then(function(res) {
                               if(res) {
                                $scope.sendObservDataToDb($scope.obsevationDataToSend, Time);
                              //  $scope.deleteRowFromDb(Time);
                               } else {
                                  console.log('Not sure!');
                               }
                            });
                          }
                      }
                      else{
                        var confirmPopup = $ionicPopup.confirm({
                           title: 'Data Upload',
                           template: 'your data is going to be uploaded'
                        });

                        confirmPopup.then(function(res) {
                           if(res) {
                             $scope.sendObservDataToDb($scope.obsevationDataToSend, Time);

                           } else {
                              console.log('Not sure!');
                           }
                        });
                      }

                //console.log("SELECTED -> " + res.rows.item(0).firstname + " " + res.rows.item(0).lastname);
            } else {
                console.log("No results found");
            }
        }, function (err) {
            console.error(err);
        });
    }


    $scope.deleteRowFromObservDb= function(Time){
      var query = "DELETE FROM observationTable where Time = ?";
      $cordovaSQLite.execute(db, query, [Time]).then(function(res) {
      //$cordovaSQLite.execute(db, query).then(function(res) {
          if(res.rows.length > 0) {
              alert("successfully Delted");
          } else {
            observDataFetched.pop(Time);
              console.log("No results found obsv");
          }
      }, function (err) {
          console.error(err);
      });
    }


//    $scope.sendMoreDataToDb($scope.moreformData, Time);

  $scope.sendObservDataToDb = function(data_to_send, Time) {

    $http({
  method : "POST",
 url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/observationformScript.php",
  data: data_to_send,
  headers: {'Content-Type': 'application/x-www-form-urlencoded'}
  }).then(function mySuccess(response) {
$scope.deleteRowFromObservDb(Time);
    var alertPopup = $ionicPopup.alert({
      title: 'Successful',
      template: 'Your data has been submitted!'
    });

  }, function myError(response) {
    var alertPopup = $ionicPopup.alert({
      title: 'Failed',
      template: 'Please check your network'
    });
});
          }

  $scope.sendObserveDataOnline = function(field){
      $scope.selectObservData(field);



  }



})


.controller('observationformCtrl', function($scope, GeoAlert,$state,$cordovaSQLite,$ionicPopup, $ionicModal, $http, mobileDb, LoginService) {
if(firstLogin){
  stationnamefetched = LoginService.getUserStation();
  stationnumberfetched = LoginService.getUserStationNo();;
}
  $scope.userStation= stationnamefetched;   $scope.userStationNo=stationnumberfetched;

// $scope.userStation= LoginService.getUserStation();   $scope.userStationNo=LoginService.getUserStationNo();

GeoAlert.comfirmLocation();
$scope.cOptions = [
    {t : "0"},{t : "1"}, {t : "2"},{t : "3"},
    {t : "4"},{t : "5"}, {t : "6"},{t : "7"},
    {t : "8"},{t : "9"}

];
$scope.cOptions0 = [
    {t : "0"},{t : "1"}, {t : "2"},{t : "3"},
    {t : "4"},{t : "5"}, {t : "6"},{t : "7"},
    {t : "8"}

];

  function convertDate(date) {
   var yyyy = date.getFullYear().toString();
   var mm = (date.getMonth()+1).toString();
   var dd  = date.getDate().toString();

   var mmChars = mm.split('');
   var ddChars = dd.split('');

   return yyyy + '-' + (mmChars[1]?mm:"0"+mmChars[0]) + '-' + (ddChars[1]?dd:"0"+ddChars[0]);
  }
  $scope.bool_metar_speci=true;
  $scope.validateTimeDependants=function(){

  var  tymChars = $scope.observdata.time;
  $scope.reqMinutes_moreField=parseInt( tymChars.split(":")[1]);
      if($scope.reqMinutes_moreField==30 || $scope.reqMinutes_moreField==0)
      $scope.bool_metar_speci=true;   //alert("All required");
      else
       $scope.bool_metar_speci=false;   //alert("Some Not required");

  }
  $scope.checkObservationRecord= function(){
    $scope.queryData={"date":$scope.observdata.dateSelected,
                      "StationNumber":$scope.observdata.StationNumber,
                    "time":$scope.observdata.time};

  //connect to php and query db whether date, stationNo and Time exists

  $http({
  method : "POST",
  url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/queryForAll_weatherExists.php",
  data: $scope.queryData,
  headers: {'Content-Type': 'application/x-www-form-urlencoded'}
  }).then(function mySuccess(response) {
    if (response.data.code === "000") {
      console.log("weather Record Already submitted");
      alert("weather Record Already submitted");
//Four booleans are set stop progress to next page
      $scope.observationformPart1 = true;
      $scope.observationformpart2 = false;
      $scope.observationformpart3 = false;
      $scope.observationformpart4 = false;


    }
    else {
//  Record OK for submission or Network Failures
//alert(JSON.stringify(response.data));
    }

  }, function myError(response) {
  var alertPopup = $ionicPopup.alert({
  title: 'Sever Related !',
  template: 'Unknown Error!'
  });
  //Four booleans are set stop progress to next page
  $scope.observationformPart1 = true;
  $scope.observationformpart2 = false;
  $scope.observationformpart3 = false;
  $scope.observationformpart4 = false;

  });

  }
  $scope.observdata={"dateSelected":convertDate( new Date()), "StationName": $scope.userStation ,"StationNumber": $scope.userStationNo};

  $scope.checkLocation = function(){

GeoAlert.comfirmLocation();

    var lat = 0.331404;
       var long = 32.570570;
       function onConfirm(idx) {
         console.log('button '+idx+' pressed');
       }
       GeoAlert.begin(lat,long, function() {
         console.log('TARGET');
        // GeoAlert.end();

       var alertPopup = $ionicPopup.alert({
         title: 'success!',
         cssClass: 'dark',
         template: 'correct location to submit data!'
       });

       }, function() {
         console.log('TARGET_WRONG');

       var alertPopup = $ionicPopup.alert({
         title: ' failed!',
         template: 'Wrong location your going to be logged out!'
       });

       $state.go('login');
          GeoAlert.end();
       });

  }

  	$scope.openObservationForm2 = function(){
  		$state.go('main.observationform2');

  	}
  	// function to hide all other forms and leave this one available
  	$scope.hideotherObservationParts = function(){

      //mobileDb.createDb();
  			$scope.observationformPart1 = true;
  			$scope.observationformpart2 = false;
  			$scope.observationformpart3 = false;
  			$scope.observationformpart4 = false;


        $scope.observCloudsTotal  = false;
        $scope.observCloudsTotallow  = false;
        $scope.observLowCloudType  = false;
        $scope.observOktasLoCloud  = false;
        $scope.observLowCloudHeight = false;
        $scope.observecclode  = false;
        $scope.observTypmedCld = false;
        $scope.observoltasMedCld  = false;
        $scope.observHeightMedCLd = false;


        $scope.observmaxRst  = false;
        $scope.observminRead  = false;
        $scope.observminReset  = false;
        $scope.observpicheread  = false;
        $scope.observpichereset  = false;
        $scope.observtimemrksThermo  = false;
        $scope.observtimemrksHygro = false;
        $scope.observtimemrksrainrec  = false;
        $scope.observpresentWeather = false;
        $scope.observVisibilty = false;
        $scope.observwindDirection = false;
        $scope.bservwindspeed = false;
        $scope.observgusting = false;



        $scope.observclodMdClod = false;
        $scope.observTypHighCld  = false;
        $scope.observoktasHighCld = false;
        $scope.observcldhighCld = false;
        $scope.observRain = false;
        $scope.observDryBulb  = false;
        $scope.observwetBulb = false;
        $scope.observMaxRead  = false;

        $scope.observAttdThermo = false;
        $scope.observCLP = false;
        $scope.observmslpr = false;
        $scope.observTimeMarksBaroGraph  = false;
        $scope.observTimeMarksAnemoGrapgh = false;
        $scope.observOtherTMarks = false;
        $scope.observRemarks = false;
        $scope.observCorrection = false;
        $scope.observprAsReadReading = false;


  			//observationformpart2 observationformpart3 observationformpart4

  	}


    $scope.date = new Date();

    $scope.username = LoginService.getUser();

    $scope.insertObsDataOffline = function(Date,  StationName,  StationNumber,  TIME,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds,
        OktasOfLowClouds, HeightOfLowClouds, CLCODEOfLowClouds, TypeOfMediumClouds, OktasOfMediumClouds, HeightOfMediumClouds, CLCODEOfMediumClouds,
         TypeOfHighClouds, OktasOfHighClouds, HeightOfHighClouds, CLCODEOfHighClouds, CloudSearchLightReading, Rainfall,Dry_Bulb, Wet_Bulb,
         Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec ,
         Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,CLP,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,SubmittedBy,CreationDate){

        var query = "INSERT INTO observationTable (Date,  StationName,  StationNumber,  TIME,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds, OktasOfLowClouds, HeightOfLowClouds, CLCODEOfLowClouds, TypeOfMediumClouds, OktasOfMediumClouds, HeightOfMediumClouds, CLCODEOfMediumClouds,TypeOfHighClouds, OktasOfHighClouds, HeightOfHighClouds, CLCODEOfHighClouds, CloudSearchLightReading, Rainfall,Dry_Bulb, Wet_Bulb, Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec ,Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,CLP,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,SubmittedBy,CreationDate) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $cordovaSQLite.execute(db, query, [Date,  StationName,  StationNumber,  TIME,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds,
            OktasOfLowClouds, HeightOfLowClouds, CLCODEOfLowClouds, TypeOfMediumClouds, OktasOfMediumClouds, HeightOfMediumClouds, CLCODEOfMediumClouds,
             TypeOfHighClouds, OktasOfHighClouds, HeightOfHighClouds, CLCODEOfHighClouds, CloudSearchLightReading, Rainfall,Dry_Bulb, Wet_Bulb,
             Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec ,
             Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,CLP,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,SubmittedBy, CreationDate]).then(function(res) {
            console.log("INSERT ID -> " + res.insertId);
        }, function (err) {
            console.error(err);
        });




    }



  	$scope.customshowHideOfObsform = function(formpart){
  			if(formpart == "Obsform1"){
  			$scope.observationformPart1 = true;//show part 1 only
  			$scope.observationformpart2 = false;
  			$scope.observationformpart3 = false;
  			$scope.observationformpart4 = false;

  			}
  			else if(formpart=="Obsform2"){
          console.log("going to Obsform2");
        $scope.checkObservationRecord();
            if($scope.observdata.amountClounds != null && $scope.observdata.totalLowClounds != null && $scope.observdata.typeLowCloud
              != null && $scope.observdata.oktasLowClouds!= null && $scope.observdata.lowCloudHeight != null && $scope.observdata.CLCode
              != null && $scope.observdata.mediumCloudType != null && $scope.observdata.OltasMediumCloud != null && $scope.observdata.mediumCloudHeight!= null)
              {
                $scope.observationformPart1 = false;
  			        $scope.observationformpart2 = true;//show 2nd part only
  			        $scope.observationformpart3 = false;
  			        $scope.observationformpart4 = false;

                $scope.observCloudsTotal  = false;
                $scope.observCloudsTotallow  = false;
                $scope.observLowCloudType  = false;
                $scope.observOktasLoCloud  = false;
                $scope.observLowCloudHeight = false;
                $scope.observecclode  = false;
                $scope.observTypmedCld = false;
                $scope.observoltasMedCld  = false;
                $scope.observHeightMedCLd = false;

              }
              else{
                if($scope.observdata.amountClounds == null )  $scope.observCloudsTotal  = true;
                if($scope.observdata.totalLowClounds == null) $scope.observCloudsTotallow  = true;
                if($scope.observdata.typeLowCloud == null )   $scope.observLowCloudType  = true;
                if($scope.observdata.oktasLowClouds == null)  $scope.observOktasLoCloud  = true;
                if($scope.observdata.lowCloudHeight == null)  $scope.observLowCloudHeight = true;
                if($scope.observdata.CLCode == null)          $scope.observecclode  = true;
                if($scope.observdata.mediumCloudType == null) $scope.observTypmedCld = true;
                if($scope.observdata.OltasMediumCloud == null)$scope.observoltasMedCld  = true;
                if($scope.observdata.mediumCloudHeight == null)$scope.observHeightMedCLd = true;
              }



  			}
  			else if(formpart=="Obsform3"){
          //&& $scope.observdata.CLCODEOfMediumClouds != null && $scope.observdata.CLCODEOfHighClouds != null &&
          if(($scope.observdata.maxReset != null && $scope.observdata.MinRead != null && $scope.observdata.minReset != null
             && $scope.observdata.picheRead != null && $scope.observdata.picheReset!= null && $scope.observdata.picheReset!= null
             && $scope.observdata.timeMarksThermo != null && $scope.observdata.timeMarksHygro!= null &&
               $scope.observdata.timeMarksRainRec!= null && $scope.observdata.presetWeather!= null &&
               $scope.observdata.visibility!= null && $scope.observdata.windDirection!= null && $scope.observdata.windSpeed!= null
               && $scope.observdata.gusting!= null)|| (!$scope.bool_metar_speci &&  $scope.observdata.visibility!= null  && $scope.observdata.windDirection!= null && $scope.observdata.windSpeed!= null) ){

            $scope.observationformPart1 = false;
            $scope.observationformpart2 = false;
            $scope.observationformpart3 = true;//show 3rd part
            $scope.observationformpart4 = false;

            $scope.observmaxRst  = false;
            $scope.observminRead  = false;
            $scope.observminReset  = false;
            $scope.observpicheread  = false;
            $scope.observpichereset  = false;
            $scope.observtimemrksThermo  = false;
            $scope.observtimemrksHygro = false;
            $scope.observtimemrksrainrec  = false;
            $scope.observpresentWeather = false;
            $scope.observVisibilty = false;
            $scope.observwindDirection = false;
            $scope.bservwindspeed = false;
            $scope.observgusting = false;

          }
          else{
              if($scope.observdata.maxReset == null )  $scope.observmaxRst  = $scope.bool_metar_speci;
              if($scope.observdata.MinRead == null)   $scope.observminRead  = $scope.bool_metar_speci;
              if($scope.observdata.minReset == null)   $scope.observminReset  = $scope.bool_metar_speci;
              if($scope.observdata.picheRead == null )  $scope.observpicheread  = $scope.bool_metar_speci;
              if($scope.observdata.picheReset == null)  $scope.observpichereset  = $scope.bool_metar_speci;
              if($scope.observdata.timeMarksThermo == null )$scope.observtimemrksThermo  = $scope.bool_metar_speci;
              if($scope.observdata.timeMarksHygro == null)   $scope.observtimemrksHygro = $scope.bool_metar_speci;
              if($scope.observdata.timeMarksRainRec == null )$scope.observtimemrksrainrec  = $scope.bool_metar_speci;
              if($scope.observdata.presetWeather == null )  $scope.observpresentWeather = $scope.bool_metar_speci;
              if($scope.observdata.visibility == null)  $scope.observVisibilty = true;
              if($scope.observdata.windDirection == null) $scope.observwindDirection = true;
              if($scope.observdata.windSpeed == null)  $scope.bservwindspeed = true;
              if($scope.observdata.gusting == null)  $scope.observgusting = $scope.bool_metar_speci;

          }


  			}
  			else{
          if( $scope.observdata.clodeMediumCloud != null && $scope.observdata.typeHighCloud != null && $scope.observdata.oktasHighCloud
          != null && $scope.observdata.heightHighCloud != null && $scope.observdata.cloudsechlghtAlidade != null && $scope.observdata.dryBulb
          != null && $scope.observdata.wetBulb != null && $scope.observdata.maxRead != null){

            $scope.observationformPart1 = false;
            $scope.observationformpart2 = false;
            $scope.observationformpart3 = false;
            $scope.observationformpart4 = true;//show 4th part

            $scope.observclodMdClod = false;
            $scope.observTypHighCld  = false;
            $scope.observoktasHighCld = false;
            $scope.observcldhighCld = false;
            $scope.observRain = false;
            $scope.observDryBulb  = false;
            $scope.observwetBulb = false;
            $scope.observMaxRead  = false;

          }
          else {

            if($scope.observdata.clodeMediumCloud == null)    $scope.observclodMdClod = true;
            if($scope.observdata.typeHighCloud == null)       $scope.observTypHighCld  = true;
            if($scope.observdata.oktasHighCloud == null )     $scope.observoktasHighCld = true;
            if($scope.observdata.heightHighCloud == null)     $scope.observcldhighCld = true;
            if($scope.observdata.cloudsechlghtAlidade == null)$scope.observRain = $scope.bool_metar_speci;
            if($scope.observdata.rainfall == null )            $scope.observRain = $scope.bool_metar_speci;
            if($scope.observdata.dryBulb == null)             $scope.observDryBulb  = true;
            if($scope.observdata.wetBulb == null )            $scope.observwetBulb = true;
            if($scope.observdata.maxRead == null)             $scope.observMaxRead  = $scope.bool_metar_speci;
          }

  			}

  	}



$scope.submitobservationdata=function(){
$scope.checkLocation();

      if($scope.observdata.attdThermoReading != null && $scope.observdata.prAsReadReading != null && $scope.observdata.correction != null && $scope.observdata.cldMbReading
      != null && $scope.observdata.MSLPr != null && $scope.observdata.barographTimeMarks != null && $scope.observdata.anemographTimeMarks
      != null && $scope.observdata.otherTMarks != null && $scope.observdata.RemarksotherObservation != null){

        $scope.observAttdThermo = false;
        $scope.observCLP = false;
        $scope.observmslpr = false;
        $scope.observTimeMarksBaroGraph  = false;
        $scope.observTimeMarksAnemoGrapgh = false;
        $scope.observOtherTMarks = false;
        $scope.observRemarks = false;

        $scope.observData={
             "dateSelected"    :$scope.observdata.dateSelected,
             "StationName"    :$scope.observdata.StationName,
             "StationNumber"    :$scope.observdata.StationNumber ,
            "time"    :$scope.observdata.time,
             "rainfall" : $scope.observdata.rainfall,
             "amountClounds"    :$scope.observdata.amountClounds,
             "totalLowClounds"  	:$scope.observdata.totalLowClounds,
             "typeLowCloud" :$scope.observdata.typeLowCloud,
             "oktasLowClouds"    :$scope.observdata.oktasLowClouds,
             "lowCloudHeight"    : $scope.observdata.lowCloudHeight,
             "CLCode"    :	$scope.observdata.CLCode,
             "mediumCloudType"    :$scope.observdata.mediumCloudType,
             "OltasMediumCloud"    :$scope.observdata.OltasMediumCloud,
             "mediumCloudHeight"    :$scope.observdata.mediumCloudHeight,
              "CLCODEOfMediumClouds"    :$scope.observdata.CLCODEOfMediumClouds,
               "CLCODEOfHighClouds"    :$scope.observdata.CLCODEOfHighClouds,
             "maxReset"    :$scope.observdata.maxReset,
             "MinRead"    :	$scope.observdata.MinRead,
             "minReset"    :$scope.observdata.minReset,
             "picheRead"    :$scope.observdata.picheRead,
             "picheReset"    :$scope.observdata.picheReset,
             "timeMarksThermo"   :$scope.observdata.timeMarksThermo,
             "timeMarksHygro":$scope.observdata.timeMarksHygro,
              "timeMarksRainRec":$scope.observdata.timeMarksRainRec,
             "presetWeather":$scope.observdata.presetWeather,
             "visibility":$scope.observdata.visibility,
             "windDirection":$scope.observdata.windDirection,
             "windSpeed":$scope.observdata.windSpeed,
             "gusting":$scope.observdata.gusting,
             "clodeMediumCloud": $scope.observdata.clodeMediumCloud,
             "typeHighCloud":$scope.observdata.typeHighCloud,
             "oktasHighCloud": $scope.observdata.oktasHighCloud,
              "heightHighCloud":$scope.observdata.heightHighCloud,
             "cloudsechlghtAlidade":$scope.observdata.cloudsechlghtAlidade,
              "dryBulb":$scope.observdata.dryBulb,
               "wetBulb":$scope.observdata.wetBulb,
               "maxRead": $scope.observdata.maxRead,
               "attdThermoReading": $scope.observdata.attdThermoReading,
              "prAsReadReading": $scope.observdata.prAsReadReading,
              "correction": $scope.observdata.correction,
              "cldMbReading": $scope.observdata.cldMbReading,
               "MSLPr": $scope.observdata.MSLPr,
               "barographTimeMarks": $scope.observdata.barographTimeMarks,
               "anemographTimeMarks": $scope.observdata.anemographTimeMarks,
               "otherTMarks": $scope.observdata.otherTMarks,
                "RemarksotherObservation": $scope.observdata.RemarksotherObservation

        };
        if(window.Connection) {
                      if(navigator.connection.type == Connection.NONE) {
                          $ionicPopup.confirm({
                              title: "Internet Disconnected",
                              content: "The data is going to be saved offline"
                          })
                          .then(function(result) {
                              if(result) {
                                var confirmPopup = $ionicPopup.confirm({
                                   title: 'confirm subimssion',
                                   template: 'Are you sure? Changes cant be made after this'
                                });

                                confirmPopup.then(function(res) {
                                   if(res) {
                                     $scope.insertObsDataOffline($scope.observdata.dateSelected, $scope.observdata.StationName,$scope.observdata.StationNumber, $scope.observdata.time,
                                     $scope.observdata.rainfall,$scope.observdata.amountClounds,$scope.observdata.totalLowClounds,$scope.observdata.typeLowCloud,
                                     $scope.observdata.oktasLowClouds,$scope.observdata.lowCloudHeight,$scope.observdata.CLCode,$scope.observdata.mediumCloudType,
                                     $scope.observdata.OltasMediumCloud,$scope.observdata.mediumCloudHeight,$scope.observdata.CLCODEOfMediumClouds,
                                     $scope.observdata.CLCODEOfHighClouds,$scope.observdata.maxReset,$scope.observdata.MinRead,
                                     $scope.observdata.minReset,$scope.observdata.picheRead,$scope.observdata.picheReset,
                                     $scope.observdata.timeMarksThermo, $scope.observdata.timeMarksHygro, $scope.observdata.timeMarksRainRec,
                                     $scope.observdata.presetWeather,$scope.observdata.visibility,$scope.observdata.windDirection,
                                     $scope.observdata.windSpeed,$scope.observdata.gusting, $scope.observdata.clodeMediumCloud,
                                   $scope.observdata.typeHighCloud,$scope.observdata.oktasHighCloud,$scope.observdata.heightHighCloud,
                                 $scope.observdata.cloudsechlghtAlidade, $scope.observdata.dryBulb,$scope.observdata.wetBulb,
                                 $scope.observdata.maxRead,$scope.observdata.attdThermoReading,$scope.observdata.prAsReadReading, $scope.observdata.correction, $scope.observdata.cldMbReading,
                                 $scope.observdata.MSLPr,$scope.observdata.barographTimeMarks, $scope.observdata.otherTMarks,
                                 $scope.observdata.RemarksotherObservation, $scope.date, $scope.username);

                                               observDataFetched.push($scope.observdata.time);
                                       } else {
                                      console.log('Not sure!');
                                   }
                                });
                                  //ionic.Platform.exitApp();
                              }else {

                              }
                          });
                      }
                      else{
                        var confirmPopup = $ionicPopup.confirm({
                           title: 'confirm subimssion',
                           template: 'Are you sure? Changes cant be made after this'
                        });

                        confirmPopup.then(function(res) {
                           if(res) {

                                               $http({
                                              method : "POST",
                                              url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/observationformScript.php",
                                              data: $scope.observData,
                                             headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                          }).then(function mySuccess(response) {
                                             // $scope.myWelcome = response.data;
                                             var alertPopup = $ionicPopup.alert({
                                               title: 'Successful!',
                                               template: 'your data has been submitted!'
                                             })
                                          }, function myError(response) {
                                              //$scope.myWelcome = response.statusText;
                                              var alertPopup = $ionicPopup.alert({
                                                title: 'Missing fields!',
                                                template: 'Password or email is missing!'
                                              });
                                          });

                           } else {
                              console.log('Not sure!');
                           }
                        });
                      }
                  }
                  else{
                    var confirmPopup = $ionicPopup.confirm({
                       title: 'confirm subimssion',
                       template: 'Are you sure? Changes cant be made after this'
                    });

                    confirmPopup.then(function(res) {
                       if(res) {
                         $scope.insertObsDataOffline($scope.observdata.dateSelected, $scope.observdata.StationName,$scope.observdata.StationNumber, $scope.observdata.time,
                         $scope.observdata.rainfall,$scope.observdata.amountClounds,$scope.observdata.totalLowClounds,$scope.observdata.typeLowCloud,
                         $scope.observdata.oktasLowClouds,$scope.observdata.lowCloudHeight,$scope.observdata.CLCode,$scope.observdata.mediumCloudType,
                         $scope.observdata.OltasMediumCloud,$scope.observdata.mediumCloudHeight,$scope.observdata.CLCODEOfMediumClouds,
                         $scope.observdata.CLCODEOfHighClouds,$scope.observdata.maxReset,$scope.observdata.MinRead,
                         $scope.observdata.minReset,$scope.observdata.picheRead,$scope.observdata.picheReset,
                         $scope.observdata.timeMarksThermo, $scope.observdata.timeMarksHygro, $scope.observdata.timeMarksRainRec,
                         $scope.observdata.presetWeather,$scope.observdata.visibility,$scope.observdata.windDirection,
                         $scope.observdata.windSpeed,$scope.observdata.gusting, $scope.observdata.clodeMediumCloud,
                       $scope.observdata.typeHighCloud,$scope.observdata.oktasHighCloud,$scope.observdata.heightHighCloud,
                     $scope.observdata.cloudsechlghtAlidade, $scope.observdata.dryBulb,$scope.observdata.wetBulb,
                     $scope.observdata.maxRead,$scope.observdata.attdThermoReading,$scope.observdata.prAsReadReading, $scope.observdata.correction, $scope.observdata.cldMbReading,
                     $scope.observdata.MSLPr,$scope.observdata.barographTimeMarks, $scope.observdata.otherTMarks,
                     $scope.observdata.RemarksotherObservation, $scope.date, $scope.username);

                                   observDataFetched.push($scope.observdata.time);


                                                     $http({
                                                    method : "POST",
                                                    url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/observationformScript.php",
                                                    data: $scope.observData,
                                                   headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                                }).then(function mySuccess(response) {
                                                   // $scope.myWelcome = response.data;
                                                   var alertPopup = $ionicPopup.alert({
                                                     title: 'Successful!',
                                                     template: 'your data has been submitted!'
                                                   })
                                                }, function myError(response) {
                                                    //$scope.myWelcome = response.statusText;
                                                    var alertPopup = $ionicPopup.alert({
                                                      title: 'Missing fields!',
                                                      template: 'Password or email is missing!'
                                                    });
                                                });


                       } else {
                          console.log('Not sure!');
                       }
                    });
                  }




      }

      else {
          if($scope.observdata.attdThermoReading == null) $scope.observAttdThermo = $scope.bool_metar_speci;;
          if($scope.observdata.prAsReadReading == null)   $scope.observprAsReadReading = $scope.bool_metar_speci;;
          if($scope.observdata.correction == null)        $scope.observCorrection = $scope.bool_metar_speci;;
          if($scope.observdata.cldMbReading == null)       $scope.observCLP = true;
          if($scope.observdata.MSLPr == null)             $scope.observmslpr = $scope.bool_metar_speci;;
          if($scope.observdata.barographTimeMarks == null) $scope.observTimeMarksBaroGraph  = $scope.bool_metar_speci;;
          if($scope.observdata.anemographTimeMarks == null)$scope.observTimeMarksAnemoGrapgh = $scope.bool_metar_speci;;
          if($scope.observdata.otherTMarks == null)        $scope.observOtherTMarks = true;
          if($scope.observdata.RemarksotherObservation == null)$scope.observRemarks = true;

      }
    //submitObservation

       }

})
.controller('observationform2Ctrl', function($scope, $state, $ionicModal , GeoAlert, $ionicPopup) {

	/*function showMap(coords) {
    var mapOptions = {
      center: { lat: coords.latitude, lng: coords.longitude},
      zoom: 8
    };
    var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
  }

  GeoService.getPosition()
    .then(function(position) {
      $scope.coords = position.coords;
      showMap(position.coords);
    }, function(err) {
      console.log('getCurrentPosition error: ' + angular.toJson(err));
    });*/



	//submitobservationformdata openObservationForm3 openObservationForm2
})

.controller('moreformfieldsformCtrl', function($scope, $state,GeoAlert, $ionicModal, $http, $ionicPopup, LoginService, $cordovaSQLite) {


  function convertDate(date) {
   var yyyy = date.getFullYear().toString();
   var mm = (date.getMonth()+1).toString();
   var dd  = date.getDate().toString();

   var mmChars = mm.split('');
   var ddChars = dd.split('');

   return yyyy + '-' + (mmChars[1]?mm:"0"+mmChars[0]) + '-' + (ddChars[1]?dd:"0"+ddChars[0]);
  }
  $scope.userStation= stationnamefetched;   $scope.userStationNo=stationnumberfetched;

  //$scope.userStation= LoginService.getUserStation();   $scope.userStationNo=LoginService.getUserStationNo();
  $scope.moreform={"date":convertDate( new Date()), "name": $scope.userStation ,"smnumber": $scope.userStationNo};




	$scope.hideotherMoreFormParts = function(){
			$scope.moreformPart1 = true;
			$scope.moreformPart2 = false;

    $scope.MoreUnitWind = false;
    $scope.MoreIndOmission  = false;
    $scope.MooreTypeStation = false;
    $scope.MoreLowCldHeight  = false;
    $scope.MoreStdIso  = false;
    $scope.MoreGeoSTDiso  = false;
    $scope.MoreDurPrecp  = false;
    $scope.MorePastWearhe  = false;
    $scope.MoreGrassMinTemp  = false;
    $scope.MoreTypeSttn  = false;
    $scope.MoreCharInt  = false;
    $scope.MoreBegnPrecipt  = false;
    $scope.MoreIndcType  = false;
    $scope.MoreDurSun  = false;

    $scope.MorePressureSignchange = false;
    $scope.MoreSuppInfo = false;
    $scope.MoreVapourPressure = false;
    $scope.MoreWindRun = false;
    $scope.MoreTHGraph  = false;

	}
$scope.validateTimeDependants=function(){

  var  tymChars = $scope.moreform.time;

  $scope.reqMinutes_moreField=parseInt( tymChars.split(":")[1]);
if($scope.reqMinutes_moreField==30 || $scope.reqMinutes_moreField==0)
alert("All required");
else
alert("Some Not required");

}
$scope.customshowHideOfMorformParts = function(formpart){
//'Metarform2'
var  tymChars = $scope.moreform.time;
var dateObj= new Date(2017, 7, 20, parseInt(tymChars.split(":")[0]),parseInt( tymChars.split(":")[1]), 00, 00);
var reqTime=(dateObj.getUTCHours()<10?"0"+dateObj.getUTCHours():dateObj.getUTCHours())+""+dateObj.getUTCMinutes()+"Z";
    //MoreUnitWind MoreIndOmission MooreTypeStation MoreLowCldHeight MoreStdIso MoreGeoSTDiso MoreDurPrecp
    //MorePastWearhe MoreGrassMinTemp MoreTypeSttn MoreCharInt MoreBegnPrecipt MoreIndcType MoreDurSun
  //  MorePressureSignchange MoreSuppInfo MoreVapourPressure MoreWindRun MoreTHGraph
		if(formpart =='Moreform2'){
        if($scope.moreform.preciptationperiod != null && $scope.moreform.geopotential  != null && $scope.moreform.stdiosbaricsurface != null && $scope.moreform.lowcloudheight
          != null && $scope.moreform.stationtype != null && $scope.moreform.IndOrOmissionOfPrecipitation  != null && $scope.moreform.windspeed  != null){


            $scope.moreformPart1 = false;
            $scope.moreformPart2 = true;


            $scope.MoreUnitWind = false;
            $scope.MoreIndOmission  = false;
            $scope.MooreTypeStation = false;
            $scope.MoreLowCldHeight  = false;
            $scope.MoreStdIso  = false;
            $scope.MoreGeoSTDiso  = false;
            $scope.MoreDurPrecp  = false;
          }
          else{
            if($scope.moreform.windspeed  == null){
              $scope.MoreUnitWind = true;

            }
            if($scope.moreform.IndOrOmissionOfPrecipitation  == null){
              $scope.MoreIndOmission  = true;

            }
            if($scope.moreform.stationtype == null ){
              $scope.MooreTypeStation = true;

            }
            if($scope.moreform.lowcloudheight == null ){
              $scope.MoreLowCldHeight  = true;

            }
            if($scope.moreform.stdiosbaricsurface == null){
              $scope.MoreStdIso  = true;

            }
            if($scope.moreform.geopotential  == null){
              $scope.MoreGeoSTDiso  = true;

            }
            if($scope.moreform.preciptationperiod == null){
                    $scope.MoreDurPrecp  = true;
            }



          }


      }
			else{
			$scope.moreformPart1 = true;
			$scope.moreformPart2 = false;

			}


		}

  $scope.confirmMoreFormData = function(){
    if(window.Connection) {
                  if(navigator.connection.type == Connection.NONE) {
                      $ionicPopup.confirm({
                          title: "Internet Disconnected",
                          content: "The data is going to be saved offline"
                      })
                      .then(function(result) {
                          if(result) {
                            var confirmPopup = $ionicPopup.confirm({
                               title: 'confirm subimssion',
                               template: 'Are you sure? Changes cant be made after this'
                            });

                            confirmPopup.then(function(res) {
                               if(res) {
                                  $scope.submitMetardata();
                               } else {
                                  console.log('Not sure!');
                               }
                            });
                              //ionic.Platform.exitApp();
                          }else {

                          }
                      });
                  }
                  else{
                    var confirmPopup = $ionicPopup.confirm({
                       title: 'confirm subimssion',
                       template: 'Are you sure? Changes cant be made after this'
                    });

                    confirmPopup.then(function(res) {
                       if(res) {
                          $scope.submitMetardata();
                       } else {
                          console.log('Not sure!');
                       }
                    });
                  }
              }
              else{
                var confirmPopup = $ionicPopup.confirm({
                   title: 'confirm subimssion',
                   template: 'Are you sure? Changes cant be made after this'
                });

                confirmPopup.then(function(res) {
                   if(res) {
                      $scope.submitMetardata();
                   } else {
                      console.log('Not sure!');
                   }
                });
              }
    }

    $scope.date = new Date();
    $scope.meta={};
    $scope.username = LoginService.getUser();
    $scope.insertMoreDataOffline = function(Date, StationName, StationNumber, TIME, UnitOfWindSpeed, IndOrOmissionOfPrecipitation, TypeOfStation_Present_Past_Weather, HeightOfLowestCloud, StandardIsobaricSurface, GPM, DurationOfPeriodOfPrecipitation, Past_Weather, GrassMinTemp, CI_OfPrecipitation, BE_OfPrecipitation, IndicatorOfTypeOfIntrumentation, DurationOfSunshine, SignOfPressureChange, Supp_Info, VapourPressure, Wind_Run, T_H_Graph,SubmittedBy, CreationDate){
    var query = "INSERT INTO moreFormTable (Date, StationName, StationNumber, TIME, UnitOfWindSpeed, IndOrOmissionOfPrecipitation, TypeOfStation_Present_Past_Weather, HeightOfLowestCloud, StandardIsobaricSurface, GPM, DurationOfPeriodOfPrecipitation, Past_Weather, GrassMinTemp, CI_OfPrecipitation, BE_OfPrecipitation, IndicatorOfTypeOfIntrumentation, DurationOfSunshine, SignOfPressureChange, Supp_Info, VapourPressure, Wind_Run, T_H_Graph, SubmittedBy, CreationDate) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $cordovaSQLite.execute(db, query, [Date, StationName, StationNumber, TIME, UnitOfWindSpeed, IndOrOmissionOfPrecipitation, TypeOfStation_Present_Past_Weather, HeightOfLowestCloud, StandardIsobaricSurface, GPM, DurationOfPeriodOfPrecipitation, Past_Weather, GrassMinTemp, CI_OfPrecipitation, BE_OfPrecipitation, IndicatorOfTypeOfIntrumentation, DurationOfSunshine, SignOfPressureChange, Supp_Info, VapourPressure, Wind_Run, T_H_Graph, SubmittedBy, CreationDate]).then(function(res) {
            console.log("INSERT ID -> " + res.insertId);
        }, function (err) {
            console.error(err);
        });




    }
  $scope.selectMoreData = function() {
      var query = "SELECT * FROM moreFormTable";
      $cordovaSQLite.execute(db, query).then(function(res) {
          if(res.rows.length > 0) {
              alert("SELECTED -> " + res.rows.item(0).StationName + " " + res.rows.item(0).StationNumber);
          } else {
              console.log("No results found");
          }
      }, function (err) {
          console.error(err);
      });
}

  $scope.checkLocation = function(){

GeoAlert.comfirmLocation();

    var lat = 0.331404;
       var long = 32.570570;
       function onConfirm(idx) {
         console.log('button '+idx+' pressed');
       }
       GeoAlert.begin(lat,long, function() {
         console.log('TARGET');
        // GeoAlert.end();

       var alertPopup = $ionicPopup.alert({
         title: 'success!',
         cssClass: 'dark',
         template: 'correct location to submit data!'
       });

       }, function() {
         console.log('TARGET_WRONG');

       var alertPopup = $ionicPopup.alert({
         title: ' failed!',
         template: 'Wrong location your going to be logged out!'
       });

       $state.go('login');
          GeoAlert.end();
       });

  }

    $scope.submitmoreformdata=function(){

      $scope.checkLocation();

      if($scope.moreform.thgraph != null && $scope.moreform.windrun  != null &&
         $scope.moreform.vapourpressure  != null && $scope.moreform.suppinfo  != null &&
         $scope.moreform.pressuresign != null && $scope.moreform.sunshineduration  != null &&
         $scope.moreform.indicator  != null && $scope.moreform.beginpreciptation  != null &&
         $scope.moreform.characterintensity != null && $scope.moreform.stationtypepresent  != null &&
       $scope.moreform.grassmintemp  != null && $scope.moreform.pastweather  != null){

         $scope.MorePastWearhe  = false;
         $scope.MoreGrassMinTemp  = false;
         $scope.MoreTypeSttn  = false;
         $scope.MoreCharInt  = false;
         $scope.MoreBegnPrecipt  = false;
         $scope.MoreIndcType  = false;
         $scope.MoreDurSun  = false;

         $scope.MorePressureSignchange = false;
         $scope.MoreSuppInfo = false;
         $scope.MoreVapourPressure = false;
         $scope.MoreWindRun = false;
         $scope.MoreTHGraph  = false;


         $scope.moreformData={
             "thgraph": $scope.moreform.thgraph,
              "windrun": $scope.moreform.windrun,
              "vapourpressure": $scope.moreform.vapourpressure,
              "suppinfo": $scope.moreform.suppinfo,
              "pressuresign": $scope.moreform.pressuresign,
              "sunshineduration": $scope.moreform.sunshineduration,
              "indicator": $scope.moreform.indicator,
              "beginpreciptation": $scope.moreform.beginpreciptation,
               "characterintensity": $scope.moreform.characterintensity,
               "stationtypepresent": $scope.moreform.stationtypepresent,
               "grassmintemp": $scope.moreform.grassmintemp,
               "pastweather": $scope.moreform.pastweather,
               "preciptationperiod": $scope.moreform.preciptationperiod,
               "geopotential": $scope.moreform.geopotential,
               "stdiosbaricsurface": $scope.moreform.stdiosbaricsurface,
               "lowcloudheight": $scope.moreform.lowcloudheight,
               "stationtype": $scope.moreform.stationtype,
               "IndOrOmissionOfPrecipitation": $scope.moreform.IndOrOmissionOfPrecipitation,
               "windspeed": $scope.moreform.windspeed,
               "stime": $scope.moreform.time,
               "number": $scope.moreform.smnumber,
               "name": $scope.moreform.name,
               "sdate": $scope.moreform.date

             };

             if(window.Connection) {
                           if(navigator.connection.type == Connection.NONE) {
                               $ionicPopup.confirm({
                                   title: "Internet Disconnected",
                                   content: "The data is going to be saved offline"
                               })
                               .then(function(result) {
                                   if(result) {
                                     var confirmPopup = $ionicPopup.confirm({
                                        title: 'confirm subimssion',
                                        template: 'Are you sure? Changes cant be made after this'
                                     });

                                     confirmPopup.then(function(res) {
                                        if(res) {
                                          $scope.insertMoreDataOffline($scope.moreform.date,  $scope.moreform.name, $scope.moreform.smnumber,$scope.moreform.time, $scope.moreform.windspeed, $scope.moreform.IndOrOmissionOfPrecipitation,
                                              $scope.moreform.stationtype, $scope.moreform.lowcloudheight,$scope.moreform.stdiosbaricsurface, $scope.moreform.geopotential, $scope.moreform.preciptationperiod,$scope.moreform.pastweather, $scope.moreform.grassmintemp, $scope.moreform.characterintensity, $scope.moreform.beginpreciptation, $scope.moreform.indicator, $scope.moreform.sunshineduration, $scope.moreform.pressuresign, $scope.moreform.suppinfo,
                                              $scope.moreform.vapourpressure,$scope.moreform.windrun, $scope.moreform.thgraph,
                                              $scope.username, $scope.date);

                                              moreDataFetched.push($scope.moreform.time);
                                            } else {
                                           console.log('Not sure!');
                                        }
                                     });
                                       //ionic.Platform.exitApp();
                                   }else {

                                   }
                               });
                           }
                           else{
                             var confirmPopup = $ionicPopup.confirm({
                                title: 'confirm subimssion',
                                template: 'Are you sure? Changes cant be made after this'
                             });

                             confirmPopup.then(function(res) {
                                if(res) {
                                  $http({
                                method : "POST",
                                url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/moreform.php",
                                data: $scope.moreformData,
                                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                                }).then(function mySuccess(response) {
                                  var alertPopup = $ionicPopup.alert({
                                    title: 'Successful!',
                                    template: 'your data has been submitted!'
                                  })
                                }, function myError(response) {
                                  var alertPopup = $ionicPopup.alert({
                                    title: 'failed!',
                                    template: 'please check your network!'
                                  })
                                })
                                } else {
                                   console.log('Not sure!');
                                }
                             });
                           }
                       }
                       else{
                         var confirmPopup = $ionicPopup.confirm({
                            title: 'confirm subimssion',
                            template: 'Are you sure? Changes cant be made after this'
                         });

                         confirmPopup.then(function(res) {
                            if(res) {
                              $scope.insertMoreDataOffline($scope.moreform.date,  $scope.moreform.name, $scope.moreform.smnumber,$scope.moreform.time, $scope.moreform.windspeed, $scope.moreform.IndOrOmissionOfPrecipitation,
                                  $scope.moreform.stationtype, $scope.moreform.lowcloudheight,$scope.moreform.stdiosbaricsurface, $scope.moreform.geopotential, $scope.moreform.preciptationperiod,$scope.moreform.pastweather, $scope.moreform.grassmintemp, $scope.moreform.characterintensity, $scope.moreform.beginpreciptation, $scope.moreform.indicator, $scope.moreform.sunshineduration, $scope.moreform.pressuresign, $scope.moreform.suppinfo,
                                  $scope.moreform.vapourpressure,$scope.moreform.windrun, $scope.moreform.thgraph,
                                  $scope.username, $scope.date);

                                  moreDataFetched.push($scope.moreform.date);
                            } else {
                               console.log('Not sure!');
                            }
                         });
                       }



       }
       else{
         if($scope.moreform.thgraph == null){
            $scope.MoreTHGraph  = true;
         }
         if($scope.moreform.windrun  == null){
           $scope.MoreWindRun = true;
         }
         if($scope.moreform.vapourpressure  == null){
           $scope.MoreVapourPressure = true;
          }
         if($scope.moreform.suppinfo  == null){
          $scope.MoreSuppInfo = true;

         }
         if($scope.moreform.pressuresign == null){
          $scope.MorePressureSignchange = true;

         }
         if($scope.moreform.sunshineduration  == null){
           $scope.MoreDurSun  = true;
         }
         if($scope.moreform.indicator  == null){
          $scope.MoreIndcType  = true;
          }
         if($scope.moreform.beginpreciptation  == null){
             $scope.MoreBegnPrecipt  = true;
         }
         if($scope.moreform.characterintensity == null){
            $scope.MoreCharInt  = true;
         }
         if($scope.moreform.stationtypepresent  == null){
           $scope.MoreTypeSttn  = true;
         }
         if($scope.moreform.grassmintemp  == null){
             $scope.MoreGrassMinTemp  = true;


         }
         if($scope.moreform.pastweather  == null){
           $scope.MorePastWearhe  = true;

         }
       }




}


      })



.controller('menuCtrl', function($scope, $state, LoginService, $ionicModal) {
  if(firstLogin)
   OriginalUserName = LoginService.getUser();

  $scope.username = OriginalUserName;
  $scope.arrayOBV = observDataFetched.length + moreDataFetched.length + metarDataFetched.length;

	$scope.logout = function(){
		$state.go("login");

	}



});
